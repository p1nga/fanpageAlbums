DROP TABLE IF EXISTS `#__fanpagealbums`;
